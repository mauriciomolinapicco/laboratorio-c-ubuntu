#ifndef CLAVE_H
#define CLAVE_H

key_t creo_clave(int clave_base);

#endif
