#ifndef FUNCIONES_H
#define FUNCIONES_H

int generar_numero_random(int min, int max);
int leer_entero();
int leer_string(char *destino, int tamanio, const char *mensaje);


#endif
