#ifndef FUNCIONES_H
#define FUNCIONES_H

int generar_numero_random(int min, int max);
int generar_cantidad_random(void);
void generar_pedido(Pedido *pedido);

#endif
