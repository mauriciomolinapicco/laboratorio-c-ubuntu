Ejecutar el comando "make"

Para ejecutar el productor
./productor

Para ejecutar cada uno de los sistemas que procesan los menues:
./consumidor A
./consumidor B
./consumidor C


Se pueden correr los procesos en cualquier orden.

Se han utilizado señales, por lo tanto si se ejecuta control C se terminaran los procesos liberando la memoria utilizada.