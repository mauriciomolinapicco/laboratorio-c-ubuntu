#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "semaforos.h"
#include "archivos.h"
#include "clave.h"
#include "funciones.h"
#include "def.h"

int main(int argc, char *argv[])
{
    FILE* archivo;
    Jugada jugada;
    int id_semaforo;
    Equipo equipos[2];
    int i;

    id_semaforo = creo_semaforo();
    inicia_semaforo(id_semaforo, VERDE);

    printf("Presione ENTER despues del primer tiro idealmente...\n");
    while (getchar() != '\n');


    while(1) {
        espera_semaforo(id_semaforo);
        system("clear");
        
        equipos[0].cant_goles = 0;
        equipos[1].cant_goles = 0;
        equipos[0].cant_jugadas = 0;
        equipos[1].cant_jugadas = 0;

        archivo = abrir_archivo(FILE_NAME,"r");
        if (archivo != NULL) {

            while (leer_archivo(archivo, &jugada, sizeof(Jugada), 1) == 1) {
                printf("Jugada del equipo %d :", jugada.equipo);

                equipos[jugada.equipo].cant_jugadas++;

                if (jugada.fue_gol == 1) {
                    printf("GOOOOOLASO\n");
                    equipos[jugada.equipo].cant_goles++;
                } else {
                    printf("ERRO EL GOL! \n");
                }
                printf("-------------------\n");
            }

            printf("\n======= MARCADOR =======\n");

            for (i=0;i<2;i++) {
                printf("Equipo %d: %d goles en %d intentos \n", i, equipos[i].cant_goles, equipos[i].cant_jugadas);
            }

            if(equipos[jugada.equipo].cant_goles >= CANT_GOLES_PARA_GANAR) {
                printf("\n GANO el equipo %d porque llego a %d goles\n", jugada.equipo, CANT_GOLES_PARA_GANAR);
                cerrar_archivo(archivo);
                levanta_semaforo(id_semaforo);
                usleep(1000*500);
                return 0;
            }
            
            cerrar_archivo(archivo);

        }
        
        levanta_semaforo(id_semaforo);
        usleep(1000*500);
    }

    return 0;
}
