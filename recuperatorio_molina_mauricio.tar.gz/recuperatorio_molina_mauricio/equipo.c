#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "semaforos.h"
#include "archivos.h"
#include "clave.h"
#include "funciones.h"
#include "def.h"


int main(int argc, char *argv[])
{
    int id_semaforo;
    Jugada jugada;
    FILE* archivo;
    int tiro_equipo;
    int aleatorio;
    int equipo;
    int cant_goles=0;
    int nro_jugada=0;

    if (argc < 2) {
        perror("Se debe enviar un argumento!\n");
    }

    equipo = atoi(argv[1]);

    if (equipo != 0 && equipo != 1) {
        printf("Número de equipo inválido. Debe ser 0 o 1.\n");
        return 1;
    }

    id_semaforo = creo_semaforo();
    
    printf("Iniciando equipo %d \n", equipo);

    
    while(1) 
    {
        printf("\n --- Nueva jugada --- \n");
        printf("Ingrese un nro del 1 al 3 para patear al arco\n");

        tiro_equipo = leer_entero();
        while (tiro_equipo < 1 || tiro_equipo > 3) {
            printf("Numero invalido... Ingrese otro: 1, 2 o 3 \n");
            tiro_equipo = leer_entero();
        }
        
        aleatorio = generar_numero_random(1,3);
        printf("\nOpcion elegida: %d | Y el numero aleatorio es: %d\n", tiro_equipo, aleatorio);

        if (tiro_equipo == aleatorio) {
            cant_goles++;
            printf("EQUIPO %d: GOLLLLL \n", equipo);
            jugada.fue_gol = 1;
        } else {
            printf("EQUIPO %d: LE ERRE \n", equipo);
            jugada.fue_gol = 0;
        }

        jugada.equipo = equipo;
        nro_jugada++;

        espera_semaforo(id_semaforo);

        archivo = abrir_archivo(FILE_NAME, "a");
        if (archivo != NULL) {
            escribir_archivo(archivo, &jugada, sizeof(jugada), 1);
            cerrar_archivo(archivo);
        } else {
            perror("Error al abrir el archivo");
        }

        printf("Jugada: %d | Total de goles %d \n", nro_jugada, cant_goles);

        levanta_semaforo(id_semaforo);
        usleep(INTERVALO_PARTIDA*1000);

        if (cant_goles >= CANT_GOLES_PARA_GANAR) {
            printf("\nGANEEEE! El equipo %d es el mejor \n", equipo);
            break;
        }
    }

    return 0;
}
