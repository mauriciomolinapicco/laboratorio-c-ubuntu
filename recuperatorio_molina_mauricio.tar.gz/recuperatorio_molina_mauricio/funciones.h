#ifndef FUNCIONES_H
#define FUNCIONES_H

int generar_numero_random(int min, int max);
void leer_cadena(char *variable);
int leer_entero();

#endif
