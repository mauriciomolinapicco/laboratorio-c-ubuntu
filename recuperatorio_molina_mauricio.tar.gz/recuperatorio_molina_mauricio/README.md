# partido de futbol
Este proyecto simula un partido de futbol entre el equipo 0 y el equipo 1. Está desarrollado en C, pensado para ser compilado en Linux con `gcc` versión 4.1.

## Descripción
los equipos patean al arco y el primero que llega a TRES goles gana

Cada equipo:
- patea al arco (aleatorio entre 1 y 3)
- compara con valor aleatorio 
- tanto si es gol o no se escribe la jugada en archivo

## Compilación
El proyecto incluye un `Makefile` el cual se compila utilizando el comando "make"

## Ejecución
./panel
./equipo 0
./equipo 1
