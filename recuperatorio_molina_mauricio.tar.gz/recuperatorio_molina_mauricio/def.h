#ifndef DEF_H
#define DEF_H

#define INTERVALO 100000 /* 100ms en microsegundos */
#define INTERVALO_PARTIDA 1000
#define CLAVE_BASE 33
#define ROJO 0
#define VERDE 1
#define FILE_NAME "partido.dat"
#define LARGO_CADENA 100

#define CANT_GOLES_PARA_GANAR 3

typedef struct {
	int equipo;
	int fue_gol;
} Jugada;


typedef struct {
	int nro_equipo;
	int cant_jugadas;
	int cant_goles;
} Equipo;


#endif
