#ifndef CLAVE_H
#define CLAVE_H
#include <sys/types.h>

key_t creo_clave(int clave_base);

#endif
